function search_type(){

    let unknown = document.getElementById("Unknown");
    //console.log(unknown);

    let type = document.getElementById("input_type").value;
    //console.log(type);

    if ( unknown.src.match("../DocsImgs/jeu/Type_Acier.png")){
        if ( type == 'Combat' || type == 'combat'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Feu" || type == 'feu'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Sol"){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Dragon.png")){
        if ( type == "Fee" || type == 'fee'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Fée" || type == "fée"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Dragon" || type == 'dragon'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Glace" || type == "glace"){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/ype_Electrik.png")){
        if ( type == "Sol" || type == 'sol'){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Feu.png")){
        if ( type == "Eau" || type == 'eau'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Sol" || type == "sol"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Roche" || type == 'roche'){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Insecte.png")){
        if ( type == "Feu" || type == 'feu'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Roche" || type == "roche"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Vol" || type == 'vol'){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Plante.png")){
        if ( type == "Feu" || type == 'feu'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Poison" || type == "poison"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Glace" || type == 'glace'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Insecte" || type == "insecte"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Vol" || type == "vol"){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Psy.png")){
        if ( type == "Insecte" || type == 'insecte'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Spectre" || type == "spectre"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Ténèbres" || type == 'ténèbres'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Tenebres" || type == "tenebres"){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Sol.png")){
        if ( type == "Plante" || type == 'plante'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Eau" || type == "eau"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Glace" || type == 'glace'){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Tenebres.png")){
        if ( type == "Fee" || type == 'fee'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Fée" || type == "fée"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Combat" || type == 'combat'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Insecte" || type == "insecte"){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Combat.png")){
        if ( type == "Fee" || type == 'fee'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Fée" || type == "fée"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Psy" || type == 'psy'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Vol" || type == "vol"){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Eau.png")){
        if ( type == "Plante" || type == 'plante'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Electrique" || type == "electrique"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Électrique" || type == 'électrique'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Electrik" || type == "electrik"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Électrik" || type == "électrik"){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Fee.png")){
        if ( type == "Acier" || type == 'acier'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Poison" || type == "poison"){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Glace.png")){
        if ( type == "Roche" || type == "roche"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Feu" || type == 'feu'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Acier" || type == "acier"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Combat" || type == "combat"){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Normal.png")){
        if ( type == "Combat" || type == 'combat'){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Poison.png")){
        if ( type == "Psy" || type == 'psy'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Sol" || type == "sol"){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Roche.png")){
        if ( type == "Acier" || type == 'acier'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Combat" || type == "combat"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Eau" || type == 'eau'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Plante" || type == "plante"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Sol" || type == "sol"){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Spectre.png")){
        if ( type == "Spectre" || type == 'spectre'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Ténèbres" || type == "ténèbres"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Tenebres" || type == "tenebres"){
            console.log("Bravo");
            Ruban();
        }
    }

    if ( unknown.src.match("../DocsImgs/jeu/Type_Vol.png")){
        if ( type == "Glace" || type == 'glace'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Roche" || type == "roche"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Electrique" || type == "electrique"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Électrique" || type == 'électrique'){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Electrik" || type == "electrik"){
            console.log("Bravo");
            Ruban();
        }
        if ( type == "Électrik" || type == "électrik"){
            console.log("Bravo");
            Ruban();
        }
    }

}

function affichage_type(){

    let type_number = Math.floor(Math.random() * (17 + 1));
    let unknown = document.getElementById("Unknown");

    switch (type_number){

        case 0 :
            unknown.src = "../DocsImgs/jeu/Type_Acier.png";
            break;

        case 1 :
            unknown.src = "../DocsImgs/jeu/Type_Dragon.png";
            break;
        
        case 2 :
            unknown.src = "../DocsImgs/jeu/Type_Electrik.png";
            break;

        case 3 :
            unknown.src = "../DocsImgs/jeu/Type_Feu.png";
            break;

        case 4 :
            unknown.src = "../DocsImgs/jeu/Type_Insecte.png";
            break;
        
        case 5 :
            unknown.src = "../DocsImgs/jeu/Type_Plante.png";
            break;
    
        case 6 :
            unknown.src = "../DocsImgs/jeu/Type_Psy.png";
            break;

        case 7 :
            unknown.src = "../DocsImgs/jeu/Type_Sol.png";
            break;
        
        case 8 :
            unknown.src = "../DocsImgs/jeu/Type_Tenebres.png";
            break;

        case 9 :
            unknown.src = "../DocsImgs/jeu/Type_Combat.png";
            break;

        case 10 :
            unknown.src = "../DocsImgs/jeu/Type_Eau.png";
            break;
        
        case 11 :
            unknown.src = "../DocsImgs/jeu/Type_Fee.png";
            break;

        case 12 :
            unknown.src = "../DocsImgs/jeu/Type_Glace.png";
            break;

        case 13 :
            unknown.src = "../DocsImgs/jeu/Type_Normal.png";
            break;
        
        case 14 :
            unknown.src = "../DocsImgs/jeu/Type_Poison.png";
            break;

        case 15 :
            unknown.src = "../DocsImgs/jeu/Type_Roche.png";
            break;

        case 16 :
            unknown.src = "../DocsImgs/jeu/Type_Spectre.png";
            break;
        
        case 17 :
            unknown.src = "../DocsImgs/jeu/Type_Vol.png";
            break;
    }

}

function Ruban(){

    if ( document.getElementById("ruban1").src.match("../DocsImgs/jeu/Ruban_gris.png")){
        document.getElementById("ruban1").src = "../DocsImgs/jeu/Ruban_vert.png"
    }

    else if ( document.getElementById("ruban2").src.match("../DocsImgs/jeu/Ruban_gris.png")){
            document.getElementById("ruban2").src = "../DocsImgs/jeu/Ruban_rouge.png"
        }

        else if ( document.getElementById("ruban3").src.match("../DocsImgs/jeu/Ruban_gris.png")){
                document.getElementById("ruban3").src = "../DocsImgs/jeu/Ruban_bleu.png"
                console.log("Bravo vous avez gagner le jeu");

                document.getElementById("felicitation").innerHTML = "Félicitation ! Votre mail sera bien envoyer comme prévu";

            }
}

function Maison(){

    if ( document.getElementById("ruban1").src.match("../DocsImgs/jeu/Ruban_vert.png")){
        if ( document.getElementById("ruban2").src.match("../DocsImgs/jeu/Ruban_rouge.png")){
            if ( document.getElementById("ruban3").src.match("../DocsImgs/jeu/Ruban_gris.png")){
                window.location.replace("/html/informations-contacte.html");
            }
        }
    }

}