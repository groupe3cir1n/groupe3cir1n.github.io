function plagiat(){

    console.log("C'est pass bien de voler le contenu de d'autre site !") ;

}